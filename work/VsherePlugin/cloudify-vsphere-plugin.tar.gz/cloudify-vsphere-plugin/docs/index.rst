.. vSphere Plugin documentation master file, created by
   sphinx-quickstart on Thu Dec  8 15:54:24 2016.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Cloudify vSphere Plugin
=======================
The vSphere plugin allows users to use a vSphere based infrastructure for deploying services and applications.

Contents:

.. toctree::
    :maxdepth: 3

    requirements
    types
    examples
    changelog


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

